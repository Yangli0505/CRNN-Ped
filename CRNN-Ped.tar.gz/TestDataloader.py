# -*- coding: utf-8 -*-
"""
Created on Mon Oct  1 20:31:18 2018
This is used for loading test data.

@author: yang
"""


import numpy as np
import xlrd
import math 



class TestDataloader():
    
    def __init__(self,caseID,seq_length,delt):
    
        data_file='./Daimler_ECCV14_PedData_Smooth.xlsx'
        trainData=xlrd.open_workbook(data_file)     

        # ---------------------------pick up train data----------------------------------------
        X=[]
#        Y=[]
        
        for i in range(len(caseID)): 
            # take random cases
            sheet=trainData.sheet_by_index(caseID[i]-1)   
            
            if sheet.nrows<=2*seq_length:
                continue
            
            # position in the global coordinate
            ped_lat=np.array(sheet.col_values(2))
            ped_lon=np.array(sheet.col_values(3))   
            
            lat_pos=np.array([ped_lat])
            lat_max=math.ceil(lat_pos.max())
            lat_min=math.floor(lat_pos.min())
            
            lon_pos=np.array([ped_lon])
            lon_max=math.ceil(lon_pos.max())
            lon_min=math.floor(lon_pos.min())
                    
            # Pickup sequence samples
            j=0
            while j<=sheet.nrows-2*seq_length+1:
                # X-input
                observationSeqs=[]        
                for n in range(seq_length):                        
                    # ped features
                    n=2*n
                    posLat1=(sheet.row_values(j+n)[2]-lat_min)/(lat_max-lat_min)
                    posLon1=(sheet.row_values(j+n)[3]-lon_min)/(lon_max-lon_min)
                    tte1=sheet.row_values(j+n)[1]
                    
                    observationSeqs.append([posLat1,lat_max,lat_min,tte1]) 
                    
                X.append(observationSeqs)
                
                # Y-output
#                predictionSeqs=[]
#                for m in range(seq_length):                        
#                    # ped features 
#                    m=2*m
#                    posLat2=(sheet.row_values(j+2+m)[2]-lat_min)/(lat_max-lat_min)
#                    posLon2=(sheet.row_values(j+2+m)[3]-lon_min)/(lon_max-lon_min)  
#                    tte2=sheet.row_values(j+2+m)[1]
#                    predictionSeqs.append([posLat2,posLon2,lon_max,lon_min,lat_max,lat_min,tte2])      
#                
#                Y.append(predictionSeqs)
                
                # Sequence interval=2
                j+=delt            

          
        self.X=X
#        self.Y=Y


  
