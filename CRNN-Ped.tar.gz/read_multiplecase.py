# -*- coding: utf-8 -*-
"""
Created on Mon Nov 19 08:25:43 2018

@author: yang
"""

import scipy.io
import numpy as np
 

def get_testcase(scene_class):
    
    test_case=[] 
    test_case_a=[]
    test_case_b=[]
    test_case_c=[]
    test_case_d=[]
        
    case=[]
    
    if scene_class==2: # stopping case
        temp_s=scipy.io.loadmat('c4.mat')
        test_case=np.array(temp_s['C4'])
        print('here')
        print(len(test_case))
        for i in range(len(test_case)):
            case.append(test_case[i][0])
     
    else:
        temp_a=scipy.io.loadmat('c1.mat')
        temp_b=scipy.io.loadmat('c2.mat')
        temp_c=scipy.io.loadmat('c3.mat')
        temp_d=scipy.io.loadmat('c5.mat')
        test_case_a=np.array(temp_a['C1']) 
        test_case_b=np.array(temp_b['C2'])
        test_case_c=np.array(temp_c['C3'])  
        test_case_d=np.array(temp_d['C5']) 
        for i in range(len(test_case_a)):
            case.append(test_case_a[i][0])
        for i in range(len(test_case_b)):
            case.append(test_case_b[i][0])
        for i in range(len(test_case_c)):
            case.append(test_case_c[i][0])
        for i in range(len(test_case_d)):
            case.append(test_case_d[i][0])
      
    
    return case

my_case=get_testcase(1)
print(my_case)
print(len(my_case))