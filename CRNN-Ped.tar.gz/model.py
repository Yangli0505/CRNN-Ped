
import tensorflow as tf
import numpy as np
from tensorflow.python.ops import rnn_cell


# The Vanilla LSTM model
class Model():

    def __init__(self, args, infer=False):
        '''
        Initialisation function for the class Model.
        Params:
        args: Contains arguments required for the Model creation
        '''

        # If sampling new trajectories, then infer mode
        if infer:
            # Infer one position at a time
            args.batch_size = 1
            args.seq_length = 1

        # Store the arguments
        self.args = args
        cell = rnn_cell.BasicLSTMCell(args.rnn_size, state_is_tuple=False)
        
        # Multi-layer RNN construction
        cell = rnn_cell.MultiRNNCell([cell] * args.num_layers, state_is_tuple=False)

        # TODO: (improve) Dropout layer can be added here
        # Store the recurrent unit
        self.cell = cell

        # TODO: (resolve) Do we need to use a fixed seq_length?
        # Input data contains sequence of (x) points
        self.input_data = tf.placeholder(tf.float32, [None, args.seq_length, 1])
        # target data contains sequences of (x) points as well
        self.target_data = tf.placeholder(tf.float32, [None, args.seq_length, 1])

        # Learning rate
        self.lr = tf.Variable(args.learning_rate, trainable=False, name="learning_rate")

        # Initial cell state of the LSTM (initialised with zeros)
        self.initial_state = cell.zero_state(batch_size=args.batch_size, dtype=tf.float32)

        # Output size is the set of parameters (mu, sigma, corr)
        output_size = 2  # 1 mu, 1 sigma 

        # Embedding for the spatial coordinates
        with tf.variable_scope("coordinate_embedding"):
            embedding_w = tf.get_variable("embedding_w", [1, args.embedding_size])
            embedding_b = tf.get_variable("embedding_b", [args.embedding_size])

        # Output linear layer
        with tf.variable_scope("rnnlm"):
            output_w = tf.get_variable("output_w", [args.rnn_size, output_size], initializer=tf.truncated_normal_initializer(stddev=0.01), trainable=True)
            output_b = tf.get_variable("output_b", [output_size], initializer=tf.constant_initializer(0.01), trainable=True)

        # Split inputs according to sequences.
        inputs = tf.split(self.input_data, args.seq_length, 1)
        
        # Get a list of 2D tensors. Each of size numPoints x 2
        inputs = [tf.squeeze(input_, [1]) for input_ in inputs]

        # Embed the input spatial points into the embedding space
        embedded_inputs = []
        for x in inputs:
            # Each x is a 2D tensor of size numPoints x 2
            # Embedding layer
            embedded_x = tf.nn.relu(tf.add(tf.matmul(x, embedding_w), embedding_b))
            embedded_inputs.append(embedded_x)

        # Feed the embedded input data, the initial state of the LSTM cell, the recurrent unit to the seq2seq decoder
        outputs, last_state = tf.contrib.legacy_seq2seq.rnn_decoder(embedded_inputs, self.initial_state, cell, loop_function=None, scope="rnnlm")

        # Concatenate the outputs from the RNN decoder and reshape it to ?xargs.rnn_size
        output = tf.reshape(tf.concat(outputs, 1), [-1, args.rnn_size])

        # Apply the output linear layer
        output = tf.nn.xw_plus_b(output, output_w, output_b)
        # Store the final LSTM cell state after the input data has been feeded
        self.final_state = last_state

        # reshape target data so that it aligns with predictions
        flat_target_data = tf.reshape(self.target_data, [-1, 1])
        # Extract the x-coordinates and y-coordinates from the target data
        [x_data] = tf.split(flat_target_data, 1, 1)

        #def tf_2d_normal(x, y, mux, muy, sx, sy, rho):
        def tf_2d_normal(x, mux, sx):
            '''
            Function that implements the PDF of a 2D normal distribution
            params:
            x : input x points
            mux : mean of the distribution in x
            sx : std dev of the distribution in x

            '''
            # eq 3 in the paper
            # and eq 24 & 25 in Graves (2013)
            # Calculate (x - mux) and (y-muy)
            normx = tf.subtract(x, mux)               
            A=sx*tf.sqrt(2*np.pi)
            B=-1/2*tf.square(tf.div(normx, sx))
            result=tf.div(tf.exp(B),A)             
            self.result = result
            
            return result

        # Important difference between loss func of Social LSTM and Graves (2013)
        # is that it is evaluated over all time steps in the latter whereas it is
        # done from t_obs+1 to t_pred in the former
        def get_lossfunc(z_mux,z_sx,x_data):
            '''
            Function to calculate given a 2D distribution over x and y, and target data
            of observed x and y points
            params:
            z_mux : mean of the distribution in x     
            z_sx : std dev of the distribution in x
            x_data : target x points
  
            '''
            step = tf.constant(1e-3, dtype=tf.float32, shape=(1, 1))

            # Calculate the PDF of the data w.r.t to the distribution
            result0_1 = tf_2d_normal(x_data, z_mux, z_sx)
            result0_2 = tf_2d_normal(tf.add(x_data, step),z_mux,z_sx)
            result0 = tf.div(tf.add(result0_1, result0_2), tf.constant(2.0, dtype=tf.float32, shape=(1, 1)))
            result0 = tf.multiply(tf.multiply(result0, step), step) # why double multiply step

            # For numerical stability purposes
            epsilon = 1e-20
            # Apply the log operation
            result1 = -tf.log(tf.maximum(result0, epsilon))  # Numerical stability
            return tf.reduce_sum(result1)
     

        def get_coef(output):
            # eq 20 -> 22 of Graves (2013)
            # TODO : (resolve) Does Social LSTM paper do this as well?
            # the paper says otherwise but this is essential as we cannot
            # have negative standard deviation and correlation needs to be between
            # -1 and 1

            z = output
            # Split the output into 2 parts corresponding to means, std devs 
            z_mux, z_sx = tf.split(z, 2, 1)
            # The output must be exponentiated for the std devs
            z_sx = tf.exp(z_sx)  #-------------? ??????  ????

            return [z_mux,z_sx]

        #-------------------------------Below----------------------#
        # Extract the coef from the output of the linear layer
        [o_mux,o_sx] = get_coef(output)
        # Store the output from the model
        self.output = output

        # Store the predicted outputs
        self.mux = o_mux
        self.sx = o_sx

        # Compute the loss function
        lossfunc = get_lossfunc(o_mux, o_sx, x_data)
        # Compute the cost
        self.cost = tf.div(lossfunc, (args.batch_size * args.seq_length))
        # Get trainable_variables
        tvars = tf.trainable_variables()
        # l2 Regularization
        l2=args.lamda_param*sum(tf.nn.l2_loss(var) for var in tvars)
        self.cost=self.cost+l2
        
        self.gradients = tf.gradients(self.cost, tvars)
        grads, _ = tf.clip_by_global_norm(self.gradients, args.grad_clip)


        
        optimizer = tf.train.RMSPropOptimizer(self.lr) # (original)
        #optimizer = tf.train.AdamOptimizer(self.lr)
        #optimizer = tf.train.GradientDescentOptimizer(self.lr)  # (try)

        # Train operator
        self.train_op = optimizer.apply_gradients(zip(grads, tvars))
        
        
        
        
        
        #-------------------------------------------Inference stage------------------------------------#

    def sample(self, sess, traj, num=10):
        '''
        Given an initial trajectory (as a list of tuples of points), predict the future trajectory
        until a few timesteps
        Params:
        sess: Current session of Tensorflow
        traj: List of past trajectory points
        num: Number of time-steps into the future to be predicted
        '''
        def sample_gaussian_2d(mux, sx):
            '''
            Function to sample a point from a given 2D normal distribution
            params:
            mux : mean of the distribution in x
            sx : std dev of the distribution in x

            '''
            # Sample a point from the  normal distribution
            x = np.random.normal(mux, sx)
            return x

        # Initial state with zeros
        state = sess.run(self.cell.zero_state(1, tf.float32))

        # Iterate over all the positions seen in the trajectory
        for pos in traj[:-1]:
            # Create the input data tensor
            data = np.zeros((1, 1, 1), dtype=np.float32)
            data[0, 0, 0] = pos[0]  # x

            # Create the feed dict
            feed = {self.input_data: data, self.initial_state: state}
            # Get the final state after processing the current position
            [state] = sess.run([self.final_state], feed)

        ret = traj

        # Last position in the observed trajectory
        last_pos = traj[-1] # 

        # Construct the input data tensor for the last point
        prev_data = np.zeros((1, 1, 1), dtype=np.float32)
        prev_data[0, 0, 0] = last_pos[0]  # x
        

        for t in range(num):# 
            # Create the feed dict
            # 
            feed = {self.input_data: prev_data, self.initial_state: state}  # prev_data
            
            # Get the final state and also the coef of the distribution of the next point            
            [o_mux, o_sx, state] = sess.run([self.mux, self.sx, self.final_state], feed)

            # Sample the next point from the distribution
            next_x = sample_gaussian_2d(o_mux[0], o_sx[0])
            
            # Append the new point to the trajectory
            ret = np.vstack((ret, [next_x,last_pos[1],last_pos[2]])) # 

            # Set the current sampled position as the last observed position
            prev_data[0, 0, 0] = next_x
            

        return ret
