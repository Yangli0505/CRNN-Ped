'''
This is to test all the cases
'''
import pickle
import os
import argparse
import tensorflow as tf
import numpy as np
from model import Model




    
def get_absolute_trajectory(traj):
    '''
    Function that computes the absolute coordinates of the trajectory
    traj: (10,7)
    '''
    new_traj=np.zeros([len(traj),1])
    
    for i in range(len(traj)):
         
        real_lat=traj[i,0]*(traj[i,1]-traj[i,2])+traj[i,2]  # lat        
        new_traj[i,0]=real_lat

    return new_traj
    


def get_mean_lat_error(predicted_traj, true_traj, observed_length):
    # The data structure to store all errors
    error = np.zeros(len(true_traj) - observed_length)
    # For each point in the predicted part of the trajectory
    for i in range(observed_length, len(true_traj)):
        # The predicted position
        pred_pos = predicted_traj[i, 0:1]
        # The true position
        true_pos = true_traj[i, 0:1]

        # The euclidean distance is the error
        error[i-observed_length] = np.linalg.norm(true_pos - pred_pos)

    # Return the mean error
    return np.mean(error)



# basic parameters
parser=argparse.ArgumentParser()
parser.add_argument('--obs_length',type=int,default=8, 
                    help='Observed length of the trajectory')
parser.add_argument('--pred_length',type=int,default=8, 
                    help='Predicted length of the trajectory')

parser.add_argument('--seq_length',type=int,default=16, 
                    help='Number of test cases')

parser.add_argument('--seq_interval', type=int, default=1,
                    help='time interval when picking up sequences')


parser.add_argument('--model_checkpoint', type=str, default=None,
                    help='model checkpoint')
                    
parser.add_argument('--saving_path', type=str, default=None,
                    help='saving path')
                    
parser.add_argument('--epoch', type=str, default=None,
                    help='epoch')

parser.add_argument('--eval_res', type=str, default='eval_tmp.txt',
                    help='eval_res')
args=parser.parse_args()







if __name__ == '__main__':

    #-------------------------------------- parameters setting----------------------------------#
    print("args:",args)
    model_checkpoint = args.model_checkpoint
    model_checkpoint = model_checkpoint[:-6] # eg. epoch_2_model.ckpt-196.index -> eg. epoch_2_model.ckpt-196
    print("model_checkpoint:", model_checkpoint)

    saving_path = args.saving_path
    epoch = args.epoch
    eval_res_file = args.eval_res
    #------------------------------------Loading cache ------------------------#
    with open(os.path.join(saving_path, 'config.pkl'), 'rb') as fid: 
        saved_args = pickle.load(fid)

    test_X_cache = os.path.join(saving_path, 'test_X.pkl')
    test_Y_cache = os.path.join(saving_path, 'test_Y.pkl')
    with open(test_X_cache, 'rb') as fid:
        INPUT_test = pickle.load(fid)
    with open(test_Y_cache, 'rb') as fid:
        OUTPUT_test = pickle.load(fid)

    #------------------ model setting ----------------#
    tf.reset_default_graph()
    model=Model(saved_args,True)

    
    sess = tf.InteractiveSession() #Initialize TensorFlow session
    saver = tf.train.Saver() # Initialize TensorFlow saver
    saver.restore(sess, model_checkpoint) #restore the model at the checkpoint


    #------------------Testing ------------------------#
    num_batches=len(INPUT_test)//saved_args.batch_size
    print('num_batches of test cases:',num_batches)
    # test errors         


    lat_error_inv=0.0
    lat_error_inv_fp=0.0   

    error_each_lat_inv=0.0
    error_each_lat_inv_fp=0.0
 
   #-----------------------one by one------------------#    
    for b in range(1, num_batches+1): 
        
        batch_x=np.array(INPUT_test[b-1:b],dtype=np.float32)
        batch_x=batch_x[0]      
        obs_traj = batch_x[:args.obs_length] # observed trajectory, shape(4,3)                    
        complete_traj = model.sample(sess, obs_traj, num=args.pred_length) #(12,3)
        #-----------------error -----------------------------------------#

        
        #-----------------error with inverse-normalization---------------#
        gt_traj_inv=get_absolute_trajectory(batch_x)
        complete_traj_inv=get_absolute_trajectory(complete_traj)  
        
        lat_error_inv+=get_mean_lat_error(gt_traj_inv, complete_traj_inv, args.obs_length)
        lat_error_inv_fp+=get_mean_lat_error(gt_traj_inv, complete_traj_inv, args.seq_length-1)

    error_each_lat_inv=lat_error_inv/num_batches # all points+lat
    error_each_lat_inv_fp=lat_error_inv_fp/num_batches #final points+lat
    
    

    
    with open(eval_res_file,'w') as fid:
        # write into the file
        str_res= epoch+","+str(error_each_lat_inv)+","+str(error_each_lat_inv_fp)+'\n'
        print "str_res:", str_res
        fid.write(str_res)
   
    
    
