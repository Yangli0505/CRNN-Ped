# -*- coding: utf-8 -*-
"""
Created on Wed Dec  5 08:48:17 2018

@author: DELL
"""


import numpy as np
import xlrd
import math 



class Dataloader():
    
    def __init__(self,caseID,obs_length,seq_length,delt):
    
        data_file='./Daimler_ECCV14_PedData_Smooth.xlsx'
        
        trainData=xlrd.open_workbook(data_file)  
        
        
        # ---------------------------pick up train data----------------------------------------
        X=[]
        Y=[]
        
        for i in range(len(caseID)): 
            # take random cases
            sheet=trainData.sheet_by_index(caseID[i]-1)   
            
            
            if sheet.nrows<=2*seq_length-1:
                continue
            # make sure if it is a stopping case
            ped_lat=np.array(sheet.col_values(2))

            lat_pos=np.array([ped_lat])
            lat_max=math.ceil(lat_pos.max())
            lat_min=math.floor(lat_pos.min())




            t_key=0
            
            for k in range(sheet.nrows):
                if sheet.row_values(k)[19]==1:
                    t_key=k-10 #提前10帧  
                    #print('this is stop case,t_key={}'.format(t_key))
                    break
            
            j=0
            count=0
            
            while j<sheet.nrows-2*seq_length-1:
                
#                if caseID[i]==18:
#                    if j==sheet.nrows-2*seq_length-1:
#                        break
#                if caseID[i]==45:
#                    if j==sheet.nrows-2*seq_length+1:
#                        break
#                
#                if (t_key-j-2*obs_length)*(t_key-j-2*seq_length+2)<0 or (t_key-j-2*seq_length+2)==0: # ther is a mixed in the prediction part 
#                    j+=delt
#                    continue
#                
#                #print('j_count={}'.format(j))
#                count+=1
#                # X-input

                observationSeqs=[] 
                
                for n in range(seq_length):                        
                    
                    n=2*n  
                    
                    posLat1=(sheet.row_values(j+n)[2]-lat_min)/(lat_max-lat_min)   
                    
                    observationSeqs.append([posLat1,lat_max,lat_min]) 
                    
                X.append(observationSeqs)
                
                # Y-output
                predictionSeqs=[]
                
                for m in range(seq_length):                        
                    
                    m=2*m
                    
                    posLat2=(sheet.row_values(j+m+2)[2]-lat_min)/(lat_max-lat_min)
                    
                    predictionSeqs.append([posLat2,lat_max,lat_min])      
                
                Y.append(predictionSeqs)
                
                j+=delt
                
          
        self.X=X
        self.Y=Y
        
        
   
