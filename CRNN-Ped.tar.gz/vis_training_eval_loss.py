# -*- coding: utf-8 -*-
"""
Created on Wed Oct  3 11:34:34 2018
1. To write the eval_res_cache into eval_res 
@author: yang
"""


import numpy as np 
import argparse
# basic parameters
parser=argparse.ArgumentParser()
parser.add_argument('--training_loss_cache', type=str, default=None,
                    help='training loss cache')
parser.add_argument('--eval_res_cache', type=str, default=None,
                    help='evaluating results cache')
args=parser.parse_args()

if __name__ == '__main__':
    print "args:",args

    training_loss = np.loadtxt(args.training_loss_cache)


    fid = open(args.eval_res_cache,'r')
    file_contents = fid.readlines()
    eval_res = []
    for line in file_contents:
        line_vec = line.split(',')
        float_line = map(float,line_vec)
        eval_res.append(float_line)
    eval_res = np.array(eval_res)

    print "training_loss:", training_loss
    print "eval_res:", eval_res        
        