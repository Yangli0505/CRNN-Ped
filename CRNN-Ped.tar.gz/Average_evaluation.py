# -*- coding: utf-8 -*-
"""
Created on Wed Oct  3 11:34:34 2018
1. To plot the average performance of 4 folds for
the specified test case;
@author: yang
"""


import pickle
import os
import matplotlib.pyplot as plt
import argparse
import numpy as np
import math

parser=argparse.ArgumentParser()
parser.add_argument('--obs_length',type=int,default=8, 
                    help='Observed length of the trajectory')
parser.add_argument('--pred_length',type=int,default=8, 
                    help='Predicted length of the trajectory')

parser.add_argument('--seq_length',type=int,default=16, 
                    help='Number of test cases')

parser.add_argument('--test_case', type=int, default=None,
                    help='ID of testccase')
                    
                    
                    
args=parser.parse_args()

Predict_Traj=[]

Lat_Box=np.zeros([args.seq_length,4])

for k in range(4):
    
    tempd=[]
    saving_path='save'+str(k)+'/'+str(args.test_case)  
    save_cache = os.path.join(saving_path, 'save_data.pkl')
    with open(save_cache, 'rb') as fid:
        save_DATA=pickle.load(fid)
    
    tempa=save_DATA[0]  # gt traj before inv-normalization
    tempc=save_DATA[2]  # gt traj
    tempd=save_DATA[3]  # predictedd traj_
       
    Predict_Traj.append([tempd])
    Lat_Box[:,k]=tempd[:,0]
    


Lat_mean=np.mean(Lat_Box,axis=1,keepdims=True)



#--------------------------------------plot the figures----------------------------------------------#





#plt.figure(figsize=(10,8))

tte=tempa[:,3]
gt_tte=tempc[:,0]
pre_tte=tempd[:,0]

print('gt_tte',np.shape(gt_tte)) #[16,1]
print('pre_tte',np.shape(pre_tte))

#filename='./'+'case_'+str(args.test_case)
#if os.path.exists(filename):
#    os.remove(filename)
#
#result_case_file=open(filename,'w')
#
#for i in range(len(Lat_mean)):	
#	result_case_file.write(str(tte[i])+','+str(gt_tte[i])+','+str(pre_tte[i][0])+'\n')	
#result_case_file.close()
#

plt.figure
time_x=tempa[:,3]
l11,=plt.plot(time_x,gt_tte,color='green', marker='o')
l21,=plt.plot(time_x,pre_tte,marker='x',color='blue')
pre_tte=pre_tte.reshape(-1,1)
l31,=plt.plot(time_x[args.obs_length:args.seq_length],pre_tte[args.obs_length:args.seq_length,0],marker='*',color='red')

plt.legend(handles = [l11, l21, l31], labels = ['GT','PT-All','PT-P'], loc = 'best')
plt.xlabel('Time to event [frame]')
plt.ylabel('Lateral Position [m]')
plt.xticks(fontsize=10)
plt.yticks(fontsize=10)
plt.ylim((int(np.min(tempc[:,0]))-0.2, math.ceil(np.max(tempc[:,0]))))
my_y_ticks = np.arange(int(np.min(tempc[:,0]))-0.2, math.ceil(np.max(tempc[:,0])), 0.2)
plt.yticks(my_y_ticks)
print(int(np.min(tempc[:,0]))-0.2)

plt.grid()
plt.show()



