#!/usr/bin/env bash

k_folds=4
select_epoch=(70 80 110 140)
testcase_ID=57

for k in $(seq $k_folds) 
do 
    let k=k-1
    let epoch=${select_epoch[k]}
    echo $epoch
    saving_path="save${k}"

    model_checkpoint=`ls $saving_path/epoch_${epoch}_model.ckpt*.index`
    
    if [ -z ${model_checkpoint} ];then
        echo "models at epoch ${epoch} have not been generated!"
        continue
    fi
    

    python test_and_eval_SingleCASE.py \
        --epoch ${epoch} \
        --saving_path ${saving_path} \
        --model_checkpoint ${model_checkpoint} \
        --test_case ${testcase_ID}


done

python  Average_evaluation.py \
    --test_case ${testcase_ID}

