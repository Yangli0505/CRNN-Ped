
from __future__ import division
import tensorflow as tf
import argparse
import numpy as np
import matplotlib.pyplot as plt 
import os
import pickle
from NewDataloader_x import Dataloader
from sklearn.model_selection import KFold
import random
import time
from model import Model
import shutil
import scipy.io





def main():
    parser=argparse.ArgumentParser() 
    parser.add_argument('--rnn_size', type=int,default=128,
                        help='size of RNN hidden state')
    
    parser.add_argument('--num_layers', type=int,default=1,
                        help='num of layers in the RNN')
    
    parser.add_argument('--forget_bias', type=float,default=1.0,
                        help='forget bias in the RNN') # keep all
    
    parser.add_argument('--model', type=str,default='lstm',
                        help='rnn, gru, or lstm')
    
    parser.add_argument('--seq_length', type=int, default=16,
                        help='rnn sequence length')
    parser.add_argument('--obs_length', type=int, default=8,
                        help='rnn sequence length')

    parser.add_argument('--batch_size', type=int, default=32,
                        help='minibatch size')
    
    parser.add_argument('--embedding_size', type=int, default=128,
                        help='Embedding dimension for the spatial coordinates')
    
    parser.add_argument('--grad_clip', type=float, default=10.,
                        help='clip gradients at this value')
    
    parser.add_argument('--learning_rate',type=float, default=0.003,
                        help='learning rate')
    
    parser.add_argument('--decay_rate', type=float, default=0.95,
                        help='decay rate for rmsprop')
    
    parser.add_argument('--num_epoches',type=int, default=151,
                        help='number of epoches')

    parser.add_argument('--saving_every_epoch',type=int, default=10,
                        help='save frequency')
    
    parser.add_argument('--seq_interval', type=int, default=1,
                        help='time interval when picking up sequences')
    
    parser.add_argument('--casebatch_size', type=int, default=5,
                        help='case of minibatch size')
                        
    parser.add_argument('--keep_prob', type=float, default=0.8,
                        help='dropout keep probability')
    parser.add_argument('--lamda_param', type=float, default=0.05,
                        help='L2 regularization parameter')
    
    args=parser.parse_args()
    
    tf.reset_default_graph()
    
    train(args)
    
def train(args):
    
    model=Model(args) 
    
    print('************************Data loading***********************************8***')
    
    #-------------------k-fold validation--------------------------------------------#
   
    #r=range(58)

    #************************only cross case in included***************************#
    test_case_a=[]
    test_case_b=[]
    test_case_c=[]
    test_case_d=[]
    temp_a=scipy.io.loadmat('c1.mat')
    temp_b=scipy.io.loadmat('c2.mat')
    temp_c=scipy.io.loadmat('c3.mat')
    temp_d=scipy.io.loadmat('c5.mat')
    test_case_a=np.array(temp_a['C1']) 
    test_case_b=np.array(temp_b['C2'])
    test_case_c=np.array(temp_c['C3'])  
    test_case_d=np.array(temp_d['C5']) 
    case=[]
    
    for i in range(len(test_case_a)):
        case.append(test_case_a[i][0])
    for i in range(len(test_case_b)):
        case.append(test_case_b[i][0])
    for i in range(len(test_case_c)):
        case.append(test_case_c[i][0])
    for i in range(len(test_case_d)):
        case.append(test_case_d[i][0])
    
    r=np.array(case)

    kf=KFold(n_splits=4,shuffle=True) # 4 groups in total
    case_ID=[]      
    for train_index, test_index in kf.split(r):
        case_ID.append([train_index,test_index]) 
        print('train_index={}'.format(train_index))
        print('test_index={}'.format(test_index))
        
    #---------------------------the loop starts---------------------------------------#
        
    for k in range(4):
        
        #---------------------------saving path---------------------------------------#
        saving_path='save'+str(k)
        if os.path.exists(saving_path):
            shutil.rmtree(saving_path, ignore_errors=True) 
            
        if not os.path.exists(saving_path):
            os.makedirs(saving_path)

        with open(os.path.join(saving_path,'config.pkl'),'wb') as f: # mainly used to save the args
            pickle.dump(args,f)
            
        lossinfo_path=os.path.join(saving_path,'training_loss_info.txt')
        if os.path.exists(lossinfo_path):
            os.remove(lossinfo_path)
            
            
        # ----------------load train and test case ID---------------------------------#
            
        train_case=case_ID[k][0]   
        test_case=case_ID[k][1]    

        test_Dataloader=Dataloader(test_case,args.obs_length,args.seq_length, args.seq_interval)
        INPUT_test=test_Dataloader.X
        OUTPUT_test=test_Dataloader.Y  
        print('len of test_data',len(INPUT_test))
        test_X_cache = os.path.join(saving_path, 'test_X.pkl')
        test_Y_cache = os.path.join(saving_path, 'test_Y.pkl')
        with open(test_X_cache,'wb') as fid:
            pickle.dump(INPUT_test, fid)       
        with open(test_Y_cache, 'wb') as fid:
            pickle.dump(OUTPUT_test, fid) 
        

        print('************************This is  fold {} as the test set, Training begins***********************************'.format(k))
        
        with tf.Session() as sess:
            
                      
            sess.run(tf.global_variables_initializer()) 
            saver=tf.train.Saver(tf.global_variables(),max_to_keep=10) 
                                       
            # for each epoch
                           
            epoch_loss=[]
            lists_epoch_loss=[]
            
            for e in range(args.num_epoches): 
                
                # tic
                st_epoch=time.time()
#                sess.run(tf.assign(model.lr, args.learning_rate))
                #sess.run(tf.assign(model.lr, args.learning_rate * (args.decay_rate ** e)))
                
                
                # change the learning rate
                if e<=30:
                    sess.run(tf.assign(model.lr, args.learning_rate * (args.decay_rate ** e)))
                elif e<=60:
                    sess.run(tf.assign(model.lr, 0.3*args.learning_rate * (args.decay_rate ** e)))
                elif e<=91:
                    sess.run(tf.assign(model.lr, 0.1*args.learning_rate * (args.decay_rate ** e)))                  
                elif e<=121:
                    sess.run(tf.assign(model.lr, 0.005*args.learning_rate * (args.decay_rate ** e)))
                else:
                    sess.run(tf.assign(model.lr, 0.001*args.learning_rate * (args.decay_rate ** e)))

                                    
                
                # load the train case
                random.shuffle(train_case)
                train_case_epoch=np.array(train_case)   
                # put all the training case into each batch      
                ih=0                
                train_case_batch=[]
                
                while ih<len(train_case_epoch):
                    train_case_batch.append([train_case_epoch[ih:ih+args.casebatch_size]]) # 
                    ih+=args.casebatch_size 
                #-------------------------------------Start of casebatch loop--------------------------------------#
                u_temp_loss=0.0
                num_casebatch=len(train_case_batch) 
                
                for hm in range(num_casebatch):
                    temp_case=[]
                    casebatch_INPUT_train=[]
                    casebatch_OUTPUT_train=[]
                    temp_case=train_case_batch[hm][0]                    
                    casebatch_Dataloader=Dataloader(train_case,args.obs_length,args.seq_length, args.seq_interval)
                    casebatch_INPUT_train=casebatch_Dataloader.X
                    casebatch_OUTPUT_train=casebatch_Dataloader.Y
                    
                    #******************************start of minibatch loop*********************************#
                    num_batch=len(casebatch_INPUT_train)//args.batch_size
                    
                    if num_batch==0:
                    	continue

                    
                    
                    mean_mini_loss=0.0
                    temp_loss=0.0 
                    
                    for b in range(1, num_batch + 1):
                        x1=[]
                        y1=[]                  
                        p= (b - 1) * args.batch_size
                        q= b * args.batch_size
                        x1 = np.array(casebatch_INPUT_train[p:q],dtype=np.float32)  #(args.batch_size,seq_len,7)
                        y1 = np.array(casebatch_OUTPUT_train[p:q],dtype=np.float32) 
                        x11=x1[:,:,0:1]
                        y11=y1[:,:,0:1]

                        # creat feed
                        feed={model.input_data: x11, 
                              model.target_data:y11 }  ##(1,seq_len,7)
                              
                        train_loss, _ =sess.run([model.cost,model.train_op],feed)
                        temp_loss += train_loss
 
                            
                    mean_mini_loss=temp_loss/num_batch # mean loss of the mini-batches
                    
                    #******************************end of minibatch loop*********************************#
                    
                    u_temp_loss+=mean_mini_loss
                mean_loss_casebatch=u_temp_loss/num_casebatch  # calculate the average for all case-batches
                #-----------------------------End of casebatch loop----------------------------------------------------#
                
                # ************save the model**********************************#
                
                if (e+1) % args.saving_every_epoch == 0:
                    print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
                    print('epoch:{},mean loss of each window:{}'.format(e+1, mean_loss_casebatch))
                    epoch_loss.append([e+1,mean_loss_casebatch])  
                
                    checkpoint_path = os.path.join(saving_path,'epoch_{}_model.ckpt'.format(e+1))
                    saver.save(sess,checkpoint_path, global_step = (e+1)*num_casebatch)  
                
                #sav3 training loss
                mean_loss = np.array(epoch_loss)
                
                training_loss_cache = os.path.join(saving_path,'training_loss_info.txt')
                np.savetxt(training_loss_cache , mean_loss)
                
                et_epoch=time.time()
                print('epoch',e)
                print('time of the epoch',et_epoch-st_epoch) 
                
                # --------------save the loss each epoch, and plot the loss curve-------------------------------#
                
                lists_epoch_loss.append([e+1,mean_loss_casebatch])
                
            lists_epoch_loss=np.array(lists_epoch_loss)  
            
#            plt.figure()
#            plt.plot(lists_epoch_loss[:,0],lists_epoch_loss[:,1],'r-o')
#            plt.xlabel('Epoch')
#            plt.ylabel('Mean Loss')
#            plt.show()


                
                
    print("ohhhhhhhh, All of the Optimizations Finished!")  

          
if __name__=='__main__':
    main()
